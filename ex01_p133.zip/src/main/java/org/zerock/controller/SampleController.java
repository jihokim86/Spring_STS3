package org.zerock.controller;

import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.zerock.domain.SampleDTO;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/sample/*")
@Log4j
public class SampleController {
	
	@RequestMapping("")
	public void basic() {
		log.info("basic..............");
	}
	
	@RequestMapping(value="/basic",method= {RequestMethod.GET,RequestMethod.POST} )
	public void basicGET() {
		log.info("basic get...............");
	}
	
	@GetMapping("/basicOnlyGet") // get 방식으로만 받을수있음~
	public void basicGET2() {
		log.info("basic get only get..........");
	}
	
	@GetMapping("/ex01") // get 방식으로만 받을수있음~
	public String ex01(SampleDTO dto) {
		log.info(""+dto);
		return "ex01";
	}
	
	@GetMapping("/ex02") // get 방식으로만 받을수있음~
	public String ex02(@RequestParam("name") String name, @RequestParam("age") int age) {
		log.info("name="+name);
		log.info("age="+age);
		return "ex02";
	}
	
	@GetMapping("/ex03List") // get 방식으로만 받을수있음~
	public String ex03(@RequestParam("ids") ArrayList<String> ids) {
		log.info("ids="+ids);
		return "ex03List";
	}
	
	@GetMapping("/ex03Array") // get 방식으로만 받을수있음~
	public String ex03(@RequestParam("ids") String[] ids) {
		log.info("array ids="+Arrays.toString(ids));
		return "ex03Array";
	}
}
